<?php namespace App\SupportedApps\Scrutiny;

class Scrutiny extends \App\SupportedApps {

}