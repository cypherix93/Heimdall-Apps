<ul class="livestats">
    <li>
        <span class="title">Temp</span>
        <strong>{!! $cpu !!}</strong>
    </li>
    <li>
        <span class="title">RAM</span>
        <strong>{!! $ram !!}</strong>
    </li>
</ul>
