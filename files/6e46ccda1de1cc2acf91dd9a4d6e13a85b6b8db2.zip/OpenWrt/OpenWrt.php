<?php namespace App\SupportedApps\OpenWrt;

class OpenWrt extends \App\SupportedApps {

}