<?php namespace App\SupportedApps\Airsonic;

class Airsonic extends \App\SupportedApps {

}