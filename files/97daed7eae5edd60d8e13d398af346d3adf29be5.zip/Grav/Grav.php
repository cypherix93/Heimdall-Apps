<?php namespace App\SupportedApps\Grav;

class Grav extends \App\SupportedApps {

}