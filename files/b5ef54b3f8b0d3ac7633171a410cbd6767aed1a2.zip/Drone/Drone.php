<?php namespace App\SupportedApps\Drone;

class Drone extends \App\SupportedApps {

}