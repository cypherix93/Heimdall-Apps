<?php namespace App\SupportedApps\TheLounge;

class TheLounge extends \App\SupportedApps {

}