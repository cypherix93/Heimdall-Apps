<?php namespace App\SupportedApps\QNAP;

class QNAP extends \App\SupportedApps {

}