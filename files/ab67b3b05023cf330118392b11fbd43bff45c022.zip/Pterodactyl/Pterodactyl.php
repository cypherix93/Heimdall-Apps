<?php namespace App\SupportedApps\Pterodactyl;

class Pterodactyl extends \App\SupportedApps {

}