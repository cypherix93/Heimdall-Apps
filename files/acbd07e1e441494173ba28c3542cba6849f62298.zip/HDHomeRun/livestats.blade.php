<ul class="livestats">
    <li>
        <span class="title">Channels</span>
        <strong>{!! $number_of_channels !!}</strong>
    </li>
    <li>
        <span class="title">Tuners<br />In Use</span>
        <strong>{!! $tuners_in_use !!} of {!! $tuners_total !!}</strong>
    </li>
</ul>
