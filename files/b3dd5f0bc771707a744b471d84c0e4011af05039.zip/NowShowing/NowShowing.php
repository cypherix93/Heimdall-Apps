<?php namespace App\SupportedApps\NowShowing;

class NowShowing extends \App\SupportedApps {

}