<?php namespace App\SupportedApps\Photonix;

class Photonix extends \App\SupportedApps {

}